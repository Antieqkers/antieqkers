import React from 'react';

interface JobCardProps {
  company: string;
  logo: string;
  position: string;
  location: string;
  salary: string;
  type: string;
  postedDate: string;
  onApply: () => void;
}

export const JobCard: React.FC<JobCardProps> = ({ 
  company, 
  logo, 
  position, 
  location, 
  salary, 
  type,
  postedDate,
  onApply 
}) => {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 border border-gray-200">
      <div className="p-5">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0">
            <img src={logo} alt={company} className="w-12 h-12 object-contain rounded-md" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900">{position}</h3>
            <p className="text-gray-700 mb-1">{company}</p>
            <div className="flex flex-wrap gap-2 mb-3">
              <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                {location}
              </span>
              <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                {type}
              </span>
              <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded">
                {salary}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <p className="text-gray-500 text-sm">Diposting {postedDate}</p>
              <button
                onClick={onApply}
                className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm transition-colors"
              >
                Lamar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
