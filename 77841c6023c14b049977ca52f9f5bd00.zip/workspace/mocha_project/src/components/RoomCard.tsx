import React from 'react';

interface RoomCardProps {
  image: string;
  title: string;
  price: number;
  type: string;
  facilities: string[];
  availability: string;
  onBookNow: () => void;
}

export const RoomCard: React.FC<RoomCardProps> = ({ 
  image, 
  title, 
  price, 
  type, 
  facilities, 
  availability,
  onBookNow 
}) => {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200">
      <div className="h-56 overflow-hidden">
        <img src={image} alt={title} className="w-full h-full object-cover" />
      </div>
      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-gray-800">{title}</h3>
          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
            availability === "Tersedia" 
              ? "bg-green-100 text-green-800" 
              : "bg-red-100 text-red-800"
          }`}>
            {availability}
          </span>
        </div>
        <p className="text-gray-600 mb-2 text-sm">{type}</p>
        <div className="mb-4">
          <p className="text-gray-600 text-sm mb-1">Fasilitas:</p>
          <div className="flex flex-wrap gap-1">
            {facilities.map((facility, index) => (
              <span key={index} className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">
                {facility}
              </span>
            ))}
          </div>
        </div>
        <div className="flex justify-between items-center">
          <p className="text-indigo-700 font-bold text-lg">Rp {price.toLocaleString('id-ID')}/bulan</p>
          <button
            onClick={onBookNow}
            disabled={availability !== "Tersedia"}
            className={`px-4 py-2 rounded-lg text-white font-medium text-sm ${
              availability === "Tersedia"
                ? "bg-indigo-600 hover:bg-indigo-700"
                : "bg-gray-400 cursor-not-allowed"
            }`}
          >
            Pesan Sekarang
          </button>
        </div>
      </div>
    </div>
  );
};
