import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'small' | 'medium' | 'large';
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'medium' }) => {
  const sizeClasses = {
    small: 'h-8',
    medium: 'h-10',
    large: 'h-16'
  };

  return (
    <div className={`flex items-center ${className}`}>
      <img 
        src="https://mocha-cdn.com/0197f812-544a-75a6-99f1-04aa6b8af7cf/WhatsApp-Image-2025-06-27-at-14.06..jpeg" 
        alt="ANTIEQkers Logo" 
        className={`${sizeClasses[size]} rounded-md object-contain`}
      />
    </div>
  );
};

export default Logo;
