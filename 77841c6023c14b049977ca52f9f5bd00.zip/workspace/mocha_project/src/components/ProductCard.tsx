import React from 'react';

interface ProductCardProps {
  image: string;
  title: string;
  price: number;
  category: string;
  onAddToCart?: () => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ image, title, price, category, onAddToCart }) => {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
      <div className="h-48 overflow-hidden">
        <img src={image} alt={title} className="w-full h-full object-cover" />
      </div>
      <div className="p-4">
        <span className="text-xs font-semibold inline-block py-1 px-2 rounded-full bg-purple-100 text-purple-700 mb-2">
          {category}
        </span>
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        <div className="flex justify-between items-center">
          <p className="text-gray-700 font-bold">Rp {price.toLocaleString('id-ID')}</p>
          <button
            onClick={onAddToCart}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded-md transition-colors text-sm"
          >
            + Keranjang
          </button>
        </div>
      </div>
    </div>
  );
};
