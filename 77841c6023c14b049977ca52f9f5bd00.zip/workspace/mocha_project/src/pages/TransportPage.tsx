import React, { useState } from 'react';
import { Bike, Bus, Calendar, Car, Clock, MapPin, Navigation } from 'lucide-react';

export const TransportPage: React.FC = () => {
  const [transportType, setTransportType] = useState('car');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [pickup, setPickup] = useState('Kos ANTIEQkers');
  const [destination, setDestination] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);

  const transportTypes = [
    {
      id: 'bike',
      name: 'Ojek',
      icon: <Bike size={24} />,
      pricePerKm: 3000,
      maxDistance: 10,
      description: 'Cepat dan ekonomis untuk perjalanan jarak pendek'
    },
    {
      id: 'car',
      name: 'Mobil',
      icon: <Car size={24} />,
      pricePerKm: 5000,
      maxDistance: 30,
      description: 'Nyaman dan aman untuk perjalanan jarak menengah'
    },
    {
      id: 'bus',
      name: 'Bus Antar Jemput',
      icon: <Bus size={24} />,
      pricePerKm: 2000,
      maxDistance: 20,
      description: 'Ekonomis untuk perjalanan rutin (tersedia rute tertentu)'
    }
  ];

  const timeSlots = [
    '06:00 - 07:00',
    '07:00 - 08:00',
    '08:00 - 09:00',
    '09:00 - 10:00',
    '10:00 - 11:00',
    '11:00 - 12:00',
    '12:00 - 13:00',
    '13:00 - 14:00',
    '14:00 - 15:00',
    '15:00 - 16:00',
    '16:00 - 17:00',
    '17:00 - 18:00',
    '18:00 - 19:00',
    '19:00 - 20:00',
    '20:00 - 21:00',
  ];

  // Popular destinations
  const popularDestinations = [
    'Kampus Universitas Indonesia',
    'Kampus Universitas Negeri Jakarta',
    'Stasiun Depok Baru',
    'Stasiun Universitas Indonesia',
    'Mall Margocity',
    'Mall Depok Town Square',
    'Rumah Sakit UI',
    'Terminal Depok'
  ];

  // Simulate distance calculation (in real app would use Maps API)
  const calculateDistance = () => {
    // Mock distance calculation
    const destinations: { [key: string]: number } = {
      'Kampus Universitas Indonesia': 5,
      'Kampus Universitas Negeri Jakarta': 15,
      'Stasiun Depok Baru': 7,
      'Stasiun Universitas Indonesia': 4,
      'Mall Margocity': 8,
      'Mall Depok Town Square': 6,
      'Rumah Sakit UI': 5,
      'Terminal Depok': 10
    };

    return destinations[destination] || 5; // Default to 5km
  };

  const getSelectedTransport = () => {
    return transportTypes.find(t => t.id === transportType) || transportTypes[0];
  };

  const calculatePrice = () => {
    const transport = getSelectedTransport();
    const distance = calculateDistance();
    return transport.pricePerKm * distance;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination) {
      alert('Silakan masukkan tujuan Anda');
      return;
    }
    if (!date) {
      alert('Silakan pilih tanggal perjalanan');
      return;
    }
    if (!time) {
      alert('Silakan pilih waktu perjalanan');
      return;
    }
    setShowConfirmation(true);
  };

  const handleConfirm = () => {
    alert('Pesanan transportasi Anda berhasil! Pengemudi akan datang sesuai jadwal yang Anda pilih.');
    // Reset form
    setTransportType('car');
    setDate('');
    setTime('');
    setDestination('');
    setShowConfirmation(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Layanan Transportasi</h1>
          <p className="text-gray-600">Pesan layanan antar-jemput untuk kebutuhan perjalanan Anda.</p>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <form onSubmit={handleSubmit}>
              {/* Transport Type */}
              <div className="mb-8">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Pilih Jenis Transportasi</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {transportTypes.map((transport) => (
                    <div 
                      key={transport.id}
                      className={`border rounded-lg p-4 cursor-pointer transition-all ${
                        transportType === transport.id 
                          ? 'border-indigo-500 bg-indigo-50' 
                          : 'border-gray-200 hover:border-indigo-300'
                      }`}
                      onClick={() => setTransportType(transport.id)}
                    >
                      <div className="flex items-center">
                        <div className={`p-2 rounded-full mr-3 ${
                          transportType === transport.id 
                            ? 'bg-indigo-100 text-indigo-600' 
                            : 'bg-gray-100 text-gray-500'
                        }`}>
                          {transport.icon}
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">{transport.name}</h3>
                          <p className="text-sm text-gray-500">Rp {transport.pricePerKm.toLocaleString('id-ID')}/km</p>
                        </div>
                      </div>
                      <p className="mt-2 text-sm text-gray-600">{transport.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Locations */}
              <div className="mb-8">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Lokasi</h2>
                <div className="grid grid-cols-1 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Titik Penjemputan</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <MapPin size={18} className="text-gray-400" />
                      </div>
                      <input 
                        type="text"
                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        placeholder="Lokasi penjemputan"
                        value={pickup}
                        onChange={(e) => setPickup(e.target.value)}
                        disabled
                      />
                    </div>
                    <p className="text-sm text-gray-500 mt-1">Titik penjemputan default adalah lokasi kos Anda</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Tujuan</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Navigation size={18} className="text-gray-400" />
                      </div>
                      <input 
                        type="text"
                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        placeholder="Masukkan tujuan Anda"
                        value={destination}
                        onChange={(e) => setDestination(e.target.value)}
                        list="destinations"
                      />
                      <datalist id="destinations">
                        {popularDestinations.map((dest, index) => (
                          <option key={index} value={dest} />
                        ))}
                      </datalist>
                    </div>
                    <div className="mt-2">
                      <p className="text-sm font-medium text-gray-700 mb-2">Tujuan Populer:</p>
                      <div className="flex flex-wrap gap-2">
                        {popularDestinations.slice(0, 4).map((dest, index) => (
                          <button
                            key={index}
                            type="button"
                            className="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded-full text-sm text-gray-700 transition-colors"
                            onClick={() => setDestination(dest)}
                          >
                            {dest}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Schedule */}
              <div className="mb-8">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Jadwal Perjalanan</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Tanggal</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar size={18} className="text-gray-400" />
                      </div>
                      <input 
                        type="date"
                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        min={new Date().toISOString().split('T')[0]}
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Waktu</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Clock size={18} className="text-gray-400" />
                      </div>
                      <select 
                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 appearance-none bg-white"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                      >
                        <option value="">Pilih Waktu</option>
                        {timeSlots.map((slot, index) => (
                          <option key={index} value={slot}>{slot}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Summary & Submit */}
              <div className="border-t border-gray-200 pt-6">
                <div className="bg-gray-50 p-4 rounded-lg mb-6">
                  <h3 className="font-semibold text-gray-900 mb-2">Ringkasan Pesanan</h3>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Jenis Transportasi:</span>
                    <span>{getSelectedTransport().name}</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Dari:</span>
                    <span className="text-right">{pickup}</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Ke:</span>
                    <span className="text-right">{destination || '-'}</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Estimasi Jarak:</span>
                    <span>{destination ? calculateDistance() + ' km' : '-'}</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Tanggal:</span>
                    <span>{date ? new Date(date).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) : '-'}</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Waktu:</span>
                    <span>{time || '-'}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 mt-2 border-t border-gray-200">
                    <span className="font-semibold">Estimasi Harga:</span>
                    <span className="font-bold text-indigo-600">
                      {destination ? `Rp ${calculatePrice().toLocaleString('id-ID')}` : '-'}
                    </span>
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
                >
                  Pesan Sekarang
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirmation && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-indigo-100 sm:mx-0 sm:h-10 sm:w-10">
                    <Car className="h-6 w-6 text-indigo-600" />
                  </div>
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">Konfirmasi Pesanan Transportasi</h3>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500">
                        Pastikan pesanan Anda sudah benar. Pengemudi kami akan datang ke lokasi penjemputan sesuai jadwal yang dipilih.
                      </p>
                      <div className="mt-4 border-t border-gray-200 pt-4">
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Jenis Transportasi:</span>
                          <span className="font-medium">{getSelectedTransport().name}</span>
                        </div>
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Dari:</span>
                          <span className="font-medium text-right">{pickup}</span>
                        </div>
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Ke:</span>
                          <span className="font-medium text-right">{destination}</span>
                        </div>
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Estimasi Jarak:</span>
                          <span className="font-medium">{calculateDistance()} km</span>
                        </div>
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Tanggal:</span>
                          <span className="font-medium">{date ? new Date(date).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) : '-'}</span>
                        </div>
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Waktu:</span>
                          <span className="font-medium">{time}</span>
                        </div>
                        <div className="flex justify-between pt-2 mt-2 border-t border-gray-200">
                          <span className="font-semibold">Estimasi Harga:</span>
                          <span className="font-bold text-indigo-600">Rp {calculatePrice().toLocaleString('id-ID')}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-indigo-600 text-base font-medium text-white hover:bg-indigo-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={handleConfirm}
                >
                  Konfirmasi Pesanan
                </button>
                <button
                  type="button"
                  className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={() => setShowConfirmation(false)}
                >
                  Kembali
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
