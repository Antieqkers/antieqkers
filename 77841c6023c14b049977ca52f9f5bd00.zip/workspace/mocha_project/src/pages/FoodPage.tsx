import React, { useState } from 'react';
import { FoodCard } from '../components/FoodCard';
import { Filter, Search } from 'lucide-react';

export const FoodPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  // Mock food data
  const foods = [
    {
      id: 1,
      name: 'Nasi Goreng Spesial',
      restaurant: 'Warung Padang Sederhana',
      price: 25000,
      rating: 4.8,
      preparationTime: '15-25 menit',
      category: 'Makanan Indonesia',
      image: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 2,
      name: 'Ayam Bakar Taliwang',
      restaurant: 'Rumah Makan Lombok',
      price: 35000,
      rating: 4.6,
      preparationTime: '20-30 menit',
      category: 'Makanan Indonesia',
      image: 'https://images.unsplash.com/photo-1527477396000-e27163b481c2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 3,
      name: 'Mie Ayam Bakso',
      restaurant: 'Bakso Pak Joko',
      price: 20000,
      rating: 4.7,
      preparationTime: '10-15 menit',
      category: 'Makanan Indonesia',
      image: 'https://images.unsplash.com/photo-1567620832903-9fc6debc209f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 4,
      name: 'Pizza Pepperoni',
      restaurant: 'Pizza Express',
      price: 85000,
      rating: 4.5,
      preparationTime: '25-35 menit',
      category: 'Western',
      image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 5,
      name: 'Burger Cheese Deluxe',
      restaurant: 'Burger King',
      price: 45000,
      rating: 4.3,
      preparationTime: '15-20 menit',
      category: 'Western',
      image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 6,
      name: 'Sushi Roll Set',
      restaurant: 'Sushi Tei',
      price: 75000,
      rating: 4.9,
      preparationTime: '20-30 menit',
      category: 'Japanese',
      image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 7,
      name: 'Chicken Katsu',
      restaurant: 'HokBen',
      price: 38000,
      rating: 4.4,
      preparationTime: '15-25 menit',
      category: 'Japanese',
      image: 'https://images.unsplash.com/photo-1604909052743-94e838986d24?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 8,
      name: 'Beef Bowl',
      restaurant: 'Yoshinoya',
      price: 42000,
      rating: 4.6,
      preparationTime: '10-15 menit',
      category: 'Japanese',
      image: 'https://images.unsplash.com/photo-1590301157890-4810ed352733?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    }
  ];

  // Get unique categories for filter
  const categories = [...new Set(foods.map(food => food.category))];

  // Filter foods based on search term and category
  const filteredFoods = foods.filter(food => {
    const matchesSearch = food.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          food.restaurant.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === '' || food.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  const handleOrder = (foodId: number) => {
    alert(`Pesanan berhasil! Makanan Anda akan segera diantar.`);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Pesan Makanan</h1>
          <p className="text-gray-600">Pesan makanan dari restoran favorit dan nikmati di kamar Anda.</p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white p-4 rounded-lg shadow-md mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={20} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Cari makanan atau restoran..."
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="relative">
              <select
                className="block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 appearance-none bg-white"
                value={categoryFilter}
                onChange={e => setCategoryFilter(e.target.value)}
              >
                <option value="">Semua Kategori</option>
                {categories.map((category, index) => (
                  <option key={index} value={category}>{category}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <Filter size={20} className="text-gray-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Food Cards */}
        {filteredFoods.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredFoods.map(food => (
              <FoodCard
                key={food.id}
                image={food.image}
                name={food.name}
                restaurant={food.restaurant}
                price={food.price}
                rating={food.rating}
                preparationTime={food.preparationTime}
                onOrder={() => handleOrder(food.id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-lg font-medium text-gray-900">Tidak ada makanan yang sesuai dengan kriteria pencarian.</h3>
            <p className="text-gray-500 mt-2">Silakan coba dengan filter lain.</p>
          </div>
        )}
      </div>
    </div>
  );
};
