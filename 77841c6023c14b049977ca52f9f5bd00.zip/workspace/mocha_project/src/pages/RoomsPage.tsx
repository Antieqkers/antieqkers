import React, { useState } from 'react';
import { RoomCard } from '../components/RoomCard';
import { Filter, Search } from 'lucide-react';

export const RoomsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [priceFilter, setPriceFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');

  // Mock rooms data
  const rooms = [
    {
      id: 1,
      image: 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80',
      title: 'Kamar Tipe A - 203',
      price: 1500000,
      type: 'Kamar Single',
      facilities: ['AC', 'Kamar Mandi Dalam', 'WiFi', 'Lemari'],
      availability: 'Tersedia'
    },
    {
      id: 2,
      image: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80',
      title: 'Kamar Tipe B - 105',
      price: 1200000,
      type: 'Kamar Single',
      facilities: ['Kipas Angin', 'Kamar Mandi Luar', 'WiFi', 'Meja Belajar'],
      availability: 'Tersedia'
    },
    {
      id: 3,
      image: 'https://images.unsplash.com/photo-1598928636135-d146006ff4be?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80',
      title: 'Kamar Tipe C - 301',
      price: 2000000,
      type: 'Kamar Double',
      facilities: ['AC', 'Kamar Mandi Dalam', 'WiFi', 'TV', 'Lemari 2 Pintu'],
      availability: 'Tersedia'
    },
    {
      id: 4,
      image: 'https://images.unsplash.com/photo-1594434533760-02d325190e9e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80',
      title: 'Kamar Tipe A - 205',
      price: 1500000,
      type: 'Kamar Single',
      facilities: ['AC', 'Kamar Mandi Dalam', 'WiFi', 'Lemari'],
      availability: 'Tidak Tersedia'
    },
    {
      id: 5,
      image: 'https://images.unsplash.com/photo-1531835551805-16d864c8d311?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80',
      title: 'Kamar Tipe Premium - 401',
      price: 2500000,
      type: 'Kamar Premium',
      facilities: ['AC', 'Kamar Mandi Dalam', 'WiFi', 'TV', 'Kulkas Mini', 'Sofa'],
      availability: 'Tersedia'
    },
    {
      id: 6,
      image: 'https://images.unsplash.com/photo-1560448204-603b3fc33dab?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80',
      title: 'Kamar Tipe B - 107',
      price: 1200000,
      type: 'Kamar Single',
      facilities: ['Kipas Angin', 'Kamar Mandi Luar', 'WiFi', 'Meja Belajar'],
      availability: 'Tersedia'
    }
  ];

  // Filter rooms based on search term, price and type
  const filteredRooms = rooms.filter(room => {
    const matchesSearch = room.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          room.type.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesPrice = priceFilter === '' || 
                        (priceFilter === 'low' && room.price <= 1200000) ||
                        (priceFilter === 'medium' && room.price > 1200000 && room.price <= 2000000) ||
                        (priceFilter === 'high' && room.price > 2000000);
    
    const matchesType = typeFilter === '' || room.type.includes(typeFilter);
    
    return matchesSearch && matchesPrice && matchesType;
  });

  const handleBookNow = (roomId: number) => {
    alert(`Berhasil memesan kamar dengan ID: ${roomId}`);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Booking Kamar</h1>
          <p className="text-gray-600">Temukan dan booking kamar kos yang sesuai dengan kebutuhan Anda.</p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white p-4 rounded-lg shadow-md mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={20} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Cari kamar..."
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-3">
              <div className="relative">
                <select
                  className="block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 appearance-none bg-white"
                  value={priceFilter}
                  onChange={e => setPriceFilter(e.target.value)}
                >
                  <option value="">Semua Harga</option>
                  <option value="low">Rp &lt; 1.2 juta</option>
                  <option value="medium">Rp 1.2 - 2 juta</option>
                  <option value="high">Rp &gt; 2 juta</option>
                </select>
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <Filter size={20} className="text-gray-400" />
                </div>
              </div>
              <div className="relative">
                <select
                  className="block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 appearance-none bg-white"
                  value={typeFilter}
                  onChange={e => setTypeFilter(e.target.value)}
                >
                  <option value="">Semua Tipe</option>
                  <option value="Single">Single</option>
                  <option value="Double">Double</option>
                  <option value="Premium">Premium</option>
                </select>
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <Filter size={20} className="text-gray-400" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Room Cards */}
        {filteredRooms.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRooms.map(room => (
              <RoomCard
                key={room.id}
                image={room.image}
                title={room.title}
                price={room.price}
                type={room.type}
                facilities={room.facilities}
                availability={room.availability}
                onBookNow={() => handleBookNow(room.id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-lg font-medium text-gray-900">Tidak ada kamar yang sesuai dengan kriteria pencarian.</h3>
            <p className="text-gray-500 mt-2">Silakan coba dengan filter lain.</p>
          </div>
        )}
      </div>
    </div>
  );
};
