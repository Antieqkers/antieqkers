import React, { useState } from 'react';
import { Calendar, Check, Clock, RotateCcw, Shirt, Truck } from 'lucide-react';

export const LaundryPage: React.FC = () => {
  const [service, setService] = useState('regular');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [items, setItems] = useState<{ [key: string]: number }>({
    shirt: 0,
    pants: 0,
    dress: 0,
    jacket: 0,
    blanket: 0,
    other: 0
  });
  const [showConfirmation, setShowConfirmation] = useState(false);

  const services = [
    {
      id: 'regular',
      name: 'Regular (2 Hari)',
      price: 8000,
      icon: <RotateCcw size={24} />,
      description: 'Layanan cuci + setrika standar, selesai dalam 2 hari'
    },
    {
      id: 'express',
      name: 'Express (1 Hari)',
      price: 12000,
      icon: <Truck size={24} />,
      description: 'Layanan cuci + setrika cepat, selesai dalam 1 hari'
    },
    {
      id: 'premium',
      name: 'Premium (2 Hari)',
      price: 15000,
      icon: <Shirt size={24} />,
      description: 'Layanan cuci + setrika premium dengan pewangi khusus'
    }
  ];

  const timeSlots = [
    '08:00 - 10:00',
    '10:00 - 12:00',
    '13:00 - 15:00',
    '15:00 - 17:00',
    '17:00 - 19:00'
  ];

  const itemTypes = [
    { id: 'shirt', name: 'Baju', price: 1 },
    { id: 'pants', name: 'Celana', price: 1 },
    { id: 'dress', name: 'Dress', price: 2 },
    { id: 'jacket', name: 'Jaket', price: 2 },
    { id: 'blanket', name: 'Selimut', price: 3 },
    { id: 'other', name: 'Lainnya', price: 1 }
  ];

  const getTotalItems = () => {
    return Object.values(items).reduce((sum, count) => sum + count, 0);
  };

  const getTotalWeight = () => {
    let weight = 0;
    itemTypes.forEach(item => {
      weight += items[item.id] * item.price;
    });
    return weight;
  };

  const getSelectedService = () => {
    return services.find(s => s.id === service) || services[0];
  };

  const getTotalPrice = () => {
    const servicePrice = getSelectedService().price;
    return getTotalWeight() * servicePrice;
  };

  const incrementItem = (itemId: string) => {
    setItems(prev => ({ ...prev, [itemId]: prev[itemId] + 1 }));
  };

  const decrementItem = (itemId: string) => {
    if (items[itemId] > 0) {
      setItems(prev => ({ ...prev, [itemId]: prev[itemId] - 1 }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (getTotalItems() === 0) {
      alert('Silakan pilih minimal 1 item untuk di-laundry');
      return;
    }
    if (!date) {
      alert('Silakan pilih tanggal pengambilan');
      return;
    }
    if (!time) {
      alert('Silakan pilih waktu pengambilan');
      return;
    }
    setShowConfirmation(true);
  };

  const handleConfirm = () => {
    alert('Pesanan laundry Anda berhasil! Kurir kami akan datang sesuai jadwal yang Anda pilih.');
    // Reset form
    setService('regular');
    setDate('');
    setTime('');
    setItems({
      shirt: 0,
      pants: 0,
      dress: 0,
      jacket: 0,
      blanket: 0,
      other: 0
    });
    setShowConfirmation(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Layanan Laundry</h1>
          <p className="text-gray-600">Cuci pakaian Anda dengan layanan antar-jemput langsung ke kamar.</p>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <form onSubmit={handleSubmit}>
              {/* Service Type */}
              <div className="mb-8">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Pilih Jenis Layanan</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {services.map((serviceOption) => (
                    <div 
                      key={serviceOption.id}
                      className={`border rounded-lg p-4 cursor-pointer transition-all ${
                        service === serviceOption.id 
                          ? 'border-indigo-500 bg-indigo-50' 
                          : 'border-gray-200 hover:border-indigo-300'
                      }`}
                      onClick={() => setService(serviceOption.id)}
                    >
                      <div className="flex items-center">
                        <div className={`p-2 rounded-full mr-3 ${
                          service === serviceOption.id 
                            ? 'bg-indigo-100 text-indigo-600' 
                            : 'bg-gray-100 text-gray-500'
                        }`}>
                          {serviceOption.icon}
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">{serviceOption.name}</h3>
                          <p className="text-sm text-gray-500">Rp {serviceOption.price.toLocaleString('id-ID')}/kg</p>
                        </div>
                      </div>
                      <p className="mt-2 text-sm text-gray-600">{serviceOption.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Items */}
              <div className="mb-8">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Jenis dan Jumlah Pakaian</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {itemTypes.map((item) => (
                    <div key={item.id} className="flex items-center justify-between border border-gray-200 rounded-lg p-4">
                      <div>
                        <h3 className="font-medium text-gray-900">{item.name}</h3>
                        <p className="text-sm text-gray-500">{item.price} kg per item</p>
                      </div>
                      <div className="flex items-center">
                        <button 
                          type="button"
                          className="w-8 h-8 flex items-center justify-center rounded-full border border-gray-300 text-gray-600 hover:bg-gray-100"
                          onClick={() => decrementItem(item.id)}
                        >
                          -
                        </button>
                        <span className="mx-3 w-6 text-center">{items[item.id]}</span>
                        <button 
                          type="button"
                          className="w-8 h-8 flex items-center justify-center rounded-full border border-gray-300 text-gray-600 hover:bg-gray-100"
                          onClick={() => incrementItem(item.id)}
                        >
                          +
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Total Item:</span>
                    <span className="font-semibold">{getTotalItems()} item</span>
                  </div>
                  <div className="flex justify-between items-center mt-1">
                    <span className="text-gray-700">Estimasi Berat:</span>
                    <span className="font-semibold">{getTotalWeight()} kg</span>
                  </div>
                </div>
              </div>

              {/* Pickup Schedule */}
              <div className="mb-8">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Jadwal Pengambilan</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Tanggal</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar size={18} className="text-gray-400" />
                      </div>
                      <input 
                        type="date"
                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        min={new Date().toISOString().split('T')[0]}
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Waktu</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Clock size={18} className="text-gray-400" />
                      </div>
                      <select 
                        className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 appearance-none bg-white"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                      >
                        <option value="">Pilih Waktu</option>
                        {timeSlots.map((slot, index) => (
                          <option key={index} value={slot}>{slot}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Summary & Submit */}
              <div className="border-t border-gray-200 pt-6">
                <div className="bg-gray-50 p-4 rounded-lg mb-6">
                  <h3 className="font-semibold text-gray-900 mb-2">Ringkasan Pesanan</h3>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Jenis Layanan:</span>
                    <span>{getSelectedService().name}</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Total Item:</span>
                    <span>{getTotalItems()} item</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Estimasi Berat:</span>
                    <span>{getTotalWeight()} kg</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Tanggal Pengambilan:</span>
                    <span>{date ? new Date(date).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) : '-'}</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-600">Waktu Pengambilan:</span>
                    <span>{time || '-'}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 mt-2 border-t border-gray-200">
                    <span className="font-semibold">Total Harga:</span>
                    <span className="font-bold text-indigo-600">Rp {getTotalPrice().toLocaleString('id-ID')}</span>
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-lg transition-colors"
                >
                  Pesan Sekarang
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirmation && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-green-100 sm:mx-0 sm:h-10 sm:w-10">
                    <Check className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">Konfirmasi Pesanan Laundry</h3>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500">
                        Pastikan pesanan Anda sudah benar. Kurir kami akan datang ke kamar Anda sesuai jadwal yang dipilih.
                      </p>
                      <div className="mt-4 border-t border-gray-200 pt-4">
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Jenis Layanan:</span>
                          <span className="font-medium">{getSelectedService().name}</span>
                        </div>
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Total Item:</span>
                          <span className="font-medium">{getTotalItems()} item</span>
                        </div>
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Estimasi Berat:</span>
                          <span className="font-medium">{getTotalWeight()} kg</span>
                        </div>
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Tanggal Pengambilan:</span>
                          <span className="font-medium">{date ? new Date(date).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) : '-'}</span>
                        </div>
                        <div className="flex justify-between mb-1 text-sm">
                          <span className="text-gray-600">Waktu Pengambilan:</span>
                          <span className="font-medium">{time}</span>
                        </div>
                        <div className="flex justify-between pt-2 mt-2 border-t border-gray-200">
                          <span className="font-semibold">Total Harga:</span>
                          <span className="font-bold text-indigo-600">Rp {getTotalPrice().toLocaleString('id-ID')}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={handleConfirm}
                >
                  Konfirmasi Pesanan
                </button>
                <button
                  type="button"
                  className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={() => setShowConfirmation(false)}
                >
                  Kembali
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
