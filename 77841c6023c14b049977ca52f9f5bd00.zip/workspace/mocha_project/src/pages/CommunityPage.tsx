import React, { useState } from 'react';
import { Calendar, Clock, Heart, MessageCircle, Search, Users } from 'lucide-react';

export const CommunityPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  // Mock events data
  const events = [
    {
      id: 1,
      title: 'Workshop: Digital Marketing untuk Pemula',
      date: '2025-07-15',
      time: '19:00 - 21:00',
      location: 'Ruang Komunal Lt. 1',
      category: 'Workshop',
      organizer: 'Komunitas Digital ANTIEQkers',
      participants: 18,
      maxParticipants: 25,
      image: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 2,
      title: 'Nonton Bareng Final Euro 2025',
      date: '2025-07-20',
      time: '02:00 - 04:30',
      location: 'Ruang TV Lt. 2',
      category: 'Hiburan',
      organizer: 'Klub Bola ANTIEQkers',
      participants: 25,
      maxParticipants: 30,
      image: 'https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 3,
      title: 'Diskusi Buku: "Atomic Habits"',
      date: '2025-07-18',
      time: '19:30 - 21:00',
      location: 'Mini Library Lt. 3',
      category: 'Edukasi',
      organizer: 'Klub Buku ANTIEQkers',
      participants: 8,
      maxParticipants: 15,
      image: 'https://images.unsplash.com/photo-1491841550275-ad7854e35ca6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 4,
      title: 'Yoga Pagi untuk Pemula',
      date: '2025-07-17',
      time: '06:00 - 07:00',
      location: 'Taman Belakang',
      category: 'Kesehatan',
      organizer: 'Komunitas Yoga ANTIEQkers',
      participants: 12,
      maxParticipants: 20,
      image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
    }
  ];

  // Mock forum posts data
  const forumPosts = [
    {
      id: 1,
      title: 'Rekomendasi tempat makan murah di sekitar kos',
      author: 'Budi Santoso',
      date: '2025-07-10',
      category: 'Diskusi',
      comments: 15,
      likes: 24,
      content: 'Hai teman-teman, saya penghuni baru di sini. Mau tanya nih, ada rekomendasi tempat makan yang enak tapi murah di sekitar kos? Budget terbatas nih hehe. Terima kasih!'
    },
    {
      id: 2,
      title: 'Info jadwal shuttle bus ke kampus UI',
      author: 'Dina Widya',
      date: '2025-07-11',
      category: 'Informasi',
      comments: 8,
      likes: 32,
      content: 'Halo semuanya, ada yang tahu jadwal shuttle bus dari kos ke kampus UI terbaru? Di grup komunitas lama katanya ada perubahan jadwal tapi aku belum dapat infonya. Terima kasih!'
    },
    {
      id: 3,
      title: 'Ajakan belajar bareng untuk ujian TOEFL',
      author: 'Ahmad Rizki',
      date: '2025-07-09',
      category: 'Ajakan',
      comments: 20,
      likes: 18,
      content: 'Halo teman-teman! Ada yang mau belajar bareng untuk persiapan ujian TOEFL bulan depan? Aku rencana bikin grup belajar seminggu 2x di ruang komunal. Kalau tertarik, comment ya!'
    },
    {
      id: 4,
      title: 'Air di lantai 3 mati, sudah lapor admin belum?',
      author: 'Siti Nuraini',
      date: '2025-07-11',
      category: 'Keluhan',
      comments: 12,
      likes: 7,
      content: 'Teman-teman yang di lantai 3, air di kamar mandi saya tidak mengalir sejak tadi pagi. Ada yang mengalami hal yang sama? Sudah ada yang lapor ke admin kos?'
    }
  ];

  // Get unique categories for filter
  const categories = [...new Set([...events.map(event => event.category), ...forumPosts.map(post => post.category)])];

  // Filter events and posts based on search term and category
  const filteredEvents = events.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === '' || event.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const filteredPosts = forumPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          post.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === '' || post.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  // Format date
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long', year: 'numeric' };
    return new Date(dateString).toLocaleDateString('id-ID', options);
  };

  const handleJoinEvent = (eventId: number) => {
    alert('Anda telah berhasil mendaftar untuk event ini!');
  };

  const handleLikePost = (postId: number) => {
    alert('Anda menyukai postingan ini!');
  };

  const handleCommentPost = (postId: number) => {
    alert('Fitur komentar akan segera hadir!');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Komunitas ANTIEQkers</h1>
          <p className="text-gray-600">Temukan kegiatan menarik dan berinteraksi dengan penghuni kos lainnya.</p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white p-4 rounded-lg shadow-md mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={20} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Cari event atau forum..."
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="relative">
              <select
                className="block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 appearance-none bg-white"
                value={categoryFilter}
                onChange={e => setCategoryFilter(e.target.value)}
              >
                <option value="">Semua Kategori</option>
                {categories.map((category, index) => (
                  <option key={index} value={category}>{category}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Upcoming Events Section */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Event Mendatang</h2>
            <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition-colors">
              Buat Event
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredEvents.length > 0 ? (
              filteredEvents.map(event => (
                <div key={event.id} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="h-40 overflow-hidden">
                    <img src={event.image} alt={event.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-4">
                    <div className="flex items-center mb-2">
                      <Calendar size={16} className="text-indigo-600 mr-1" />
                      <span className="text-sm text-gray-600">{formatDate(event.date)}</span>
                      <span className="mx-2 text-gray-300">•</span>
                      <Clock size={16} className="text-indigo-600 mr-1" />
                      <span className="text-sm text-gray-600">{event.time}</span>
                    </div>
                    <h3 className="text-lg font-semibold mb-2 text-gray-900">{event.title}</h3>
                    <div className="flex justify-between items-center mb-3">
                      <span className="inline-block px-2 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full">
                        {event.category}
                      </span>
                      <span className="text-sm text-gray-600">{event.location}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <Users size={16} className="text-gray-400 mr-1" />
                        <span className="text-sm text-gray-600">{event.participants}/{event.maxParticipants} peserta</span>
                      </div>
                      <button
                        onClick={() => handleJoinEvent(event.id)}
                        className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-sm transition-colors"
                      >
                        Ikuti
                      </button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <h3 className="text-lg font-medium text-gray-900">Tidak ada event yang sesuai dengan kriteria pencarian.</h3>
                <p className="text-gray-500 mt-2">Silakan coba dengan filter lain.</p>
              </div>
            )}
          </div>
        </div>

        {/* Forum Section */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Forum Diskusi</h2>
            <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition-colors">
              Buat Thread
            </button>
          </div>

          <div className="space-y-6">
            {filteredPosts.length > 0 ? (
              filteredPosts.map(post => (
                <div key={post.id} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-semibold text-gray-900">{post.title}</h3>
                    <span className="inline-block px-2 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full">
                      {post.category}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-4">{post.content}</p>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <span className="text-sm font-medium text-gray-900 mr-1">{post.author}</span>
                      <span className="mx-1 text-gray-300">•</span>
                      <span className="text-sm text-gray-500">{formatDate(post.date)}</span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <button
                        onClick={() => handleLikePost(post.id)}
                        className="flex items-center text-gray-500 hover:text-indigo-600"
                      >
                        <Heart size={18} className="mr-1" />
                        <span>{post.likes}</span>
                      </button>
                      <button
                        onClick={() => handleCommentPost(post.id)}
                        className="flex items-center text-gray-500 hover:text-indigo-600"
                      >
                        <MessageCircle size={18} className="mr-1" />
                        <span>{post.comments}</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <h3 className="text-lg font-medium text-gray-900">Tidak ada diskusi yang sesuai dengan kriteria pencarian.</h3>
                <p className="text-gray-500 mt-2">Silakan coba dengan filter lain.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
