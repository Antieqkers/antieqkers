import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserCircle, Mail, Phone, Home, Settings, LogOut, CreditCard, Heart, ShoppingBag, Calendar, Clock } from 'lucide-react';

type User = {
  id: string;
  name: string;
  email: string;
  isLoggedIn: boolean;
};

export const ProfilePage: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const navigate = useNavigate();
  
  // Load user data from localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        const userData = JSON.parse(storedUser);
        if (userData.isLoggedIn) {
          setUser(userData);
        } else {
          navigate('/login');
        }
      } catch (error) {
        navigate('/login');
      }
    } else {
      navigate('/login');
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {/* Profile header */}
          <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-8">
            <div className="flex flex-col md:flex-row items-center">
              <div className="bg-white p-2 rounded-full mb-4 md:mb-0 md:mr-6">
                <UserCircle size={96} className="text-gray-600" />
              </div>
              <div className="text-center md:text-left">
                <h1 className="text-2xl font-bold text-white">{user.name}</h1>
                <p className="text-blue-100 flex items-center justify-center md:justify-start mt-1">
                  <Mail size={16} className="mr-2" /> {user.email}
                </p>
                <p className="text-blue-100 flex items-center justify-center md:justify-start mt-1">
                  <Phone size={16} className="mr-2" /> +62 81234567890
                </p>
                <p className="text-blue-100 flex items-center justify-center md:justify-start mt-1">
                  <Home size={16} className="mr-2" /> Kamar 203, ANTIEQ Boarding House
                </p>
              </div>
              <div className="mt-4 md:mt-0 md:ml-auto">
                <button 
                  onClick={() => {/* Edit profile */}} 
                  className="bg-white text-blue-600 px-4 py-2 rounded-md font-medium hover:bg-blue-50 mr-2"
                >
                  <Settings size={16} className="inline mr-1" /> Edit Profil
                </button>
                <button 
                  onClick={handleLogout}
                  className="bg-red-500 text-white px-4 py-2 rounded-md font-medium hover:bg-red-600"
                >
                  <LogOut size={16} className="inline mr-1" /> Keluar
                </button>
              </div>
            </div>
          </div>
          
          {/* Profile tabs */}
          <div className="p-4 bg-gray-50 border-b">
            <div className="flex overflow-x-auto">
              <button className="px-4 py-2 text-sm font-medium text-blue-600 border-b-2 border-blue-600 whitespace-nowrap">
                Informasi Akun
              </button>
              <button className="px-4 py-2 text-sm font-medium text-gray-500 hover:text-gray-700 whitespace-nowrap">
                Riwayat Pemesanan
              </button>
              <button className="px-4 py-2 text-sm font-medium text-gray-500 hover:text-gray-700 whitespace-nowrap">
                Pembayaran Kos
              </button>
              <button className="px-4 py-2 text-sm font-medium text-gray-500 hover:text-gray-700 whitespace-nowrap">
                Pengaturan
              </button>
            </div>
          </div>
          
          {/* Profile content */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Membership card */}
              <div className="col-span-1">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-xl p-6 text-white shadow-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-blue-100 text-sm">ANTIEQ Member</p>
                      <p className="font-bold text-xl mt-1">Gold</p>
                    </div>
                    <CreditCard size={32} />
                  </div>
                  <div className="mt-6">
                    <p className="text-xs text-blue-100">MEMBER ID</p>
                    <p className="font-mono text-lg mt-1">{user.id.toUpperCase()}</p>
                  </div>
                  <div className="mt-6">
                    <p className="text-xs text-blue-100">MEMBER SINCE</p>
                    <p className="text-lg mt-1">Jul 2025</p>
                  </div>
                </div>
                
                <div className="mt-6 bg-white rounded-lg border p-6">
                  <h3 className="font-medium text-gray-900 mb-4">Layanan Favorit</h3>
                  <ul className="space-y-3">
                    <li className="flex items-center text-sm text-gray-600">
                      <Heart size={16} className="mr-2 text-red-500" /> Laundry Kiloan
                    </li>
                    <li className="flex items-center text-sm text-gray-600">
                      <Heart size={16} className="mr-2 text-red-500" /> Gofood - Ayam Geprek
                    </li>
                    <li className="flex items-center text-sm text-gray-600">
                      <Heart size={16} className="mr-2 text-red-500" /> Mini Market - Air Mineral
                    </li>
                  </ul>
                </div>
              </div>
              
              {/* Main content */}
              <div className="col-span-1 md:col-span-2">
                <div className="bg-white rounded-lg border p-6">
                  <h3 className="font-medium text-lg text-gray-900 mb-4">Transaksi Terakhir</h3>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead>
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Layanan</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jumlah</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        <tr>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">10 Jul 2025</td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">Pembayaran Kos (Juli)</td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">Rp 1.200.000</td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                              Lunas
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">9 Jul 2025</td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">Laundry Kiloan</td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">Rp 25.000</td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                              Selesai
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">8 Jul 2025</td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">Mini Market</td>
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">Rp 42.500</td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                              Selesai
                            </span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white rounded-lg border p-6">
                    <h3 className="font-medium text-gray-900 mb-4">Jadwal Pembayaran</h3>
                    <div className="flex items-center p-4 bg-yellow-50 rounded-lg">
                      <Calendar className="h-8 w-8 text-yellow-500 mr-4" />
                      <div>
                        <p className="text-sm font-medium text-yellow-800">Tagihan Bulan Agustus</p>
                        <p className="text-xs text-yellow-700 mt-1">Jatuh tempo 5 Agustus 2025</p>
                        <p className="text-sm font-bold text-yellow-800 mt-1">Rp 1.200.000</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-lg border p-6">
                    <h3 className="font-medium text-gray-900 mb-4">Pesanan Dalam Proses</h3>
                    <div className="flex items-center p-4 bg-blue-50 rounded-lg">
                      <Clock className="h-8 w-8 text-blue-500 mr-4" />
                      <div>
                        <p className="text-sm font-medium text-blue-800">Laundry Setrika</p>
                        <p className="text-xs text-blue-700 mt-1">Estimasi selesai 12 Jul 2025</p>
                        <p className="text-sm text-blue-800 mt-1">2 kemeja, 3 celana</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 bg-white rounded-lg border p-6">
                  <h3 className="font-medium text-lg text-gray-900 mb-4">Riwayat Aktivitas</h3>
                  <div className="space-y-4">
                    <div className="flex">
                      <div className="mr-3 flex-shrink-0">
                        <ShoppingBag className="h-5 w-5 text-gray-400" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-900">Anda memesan produk dari Mini Market</p>
                        <p className="text-xs text-gray-500 mt-0.5">10 Juli 2025, 14:23</p>
                      </div>
                    </div>
                    
                    <div className="flex">
                      <div className="mr-3 flex-shrink-0">
                        <CreditCard className="h-5 w-5 text-gray-400" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-900">Pembayaran kos bulan Juli berhasil</p>
                        <p className="text-xs text-gray-500 mt-0.5">10 Juli 2025, 10:05</p>
                      </div>
                    </div>
                    
                    <div className="flex">
                      <div className="mr-3 flex-shrink-0">
                        <Shirt className="h-5 w-5 text-gray-400" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-900">Laundry kiloan Anda sudah selesai</p>
                        <p className="text-xs text-gray-500 mt-0.5">9 Juli 2025, 16:42</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;