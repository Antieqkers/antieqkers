import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { HomePage } from './pages/HomePage';
import { RoomsPage } from './pages/RoomsPage';
import { MarketPage } from './pages/MarketPage';
import { FoodPage } from './pages/FoodPage';
import { LaundryPage } from './pages/LaundryPage';
import { TransportPage } from './pages/TransportPage';
import { CommunityPage } from './pages/CommunityPage';
import { JobsPage } from './pages/JobsPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { ProfilePage } from './pages/ProfilePage';
import { Navbar } from './components/Navbar';
import './index.css';

// Main App component using the Router
export function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/rooms" element={<RoomsPage />} />
            <Route path="/market" element={<MarketPage />} />
            <Route path="/food" element={<FoodPage />} />
            <Route path="/laundry" element={<LaundryPage />} />
            <Route path="/transport" element={<TransportPage />} />
            <Route path="/community" element={<CommunityPage />} />
            <Route path="/jobs" element={<JobsPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/profile" element={<ProfilePage />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;