import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Briefcase, Car, Coffee, House, Menu, Shirt, ShoppingBag, Users, X, UserCircle, LogIn } from 'lucide-react';
import { Logo } from './Logo';

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Check if user is logged in on component mount and when localStorage changes
    const checkLoginStatus = () => {
      const storedUser = localStorage.getItem('user');
      if (storedUser) {
        try {
          const userData = JSON.parse(storedUser);
          setIsLoggedIn(userData.isLoggedIn);
        } catch (error) {
          setIsLoggedIn(false);
        }
      } else {
        setIsLoggedIn(false);
      }
    };
    
    checkLoginStatus();
    
    // Listen for changes in localStorage
    window.addEventListener('storage', checkLoginStatus);
    
    return () => {
      window.removeEventListener('storage', checkLoginStatus);
    };
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="bg-gradient-to-r from-cyan-600 to-blue-700 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center gap-2">
              <Logo size="small" />
              <span className="font-bold text-xl">
                <span className="text-yellow-400">ANTIEQ</span>kers
              </span>
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link to="/" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-500 transition-colors">
                <House className="inline mr-1" size={18} /> Beranda
              </Link>
              <Link to="/rooms" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-500 transition-colors">
                <House className="inline mr-1" size={18} /> Kamar
              </Link>
              <Link to="/market" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-500 transition-colors">
                <ShoppingBag className="inline mr-1" size={18} /> Mini Market
              </Link>
              <Link to="/food" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-500 transition-colors">
                <Coffee className="inline mr-1" size={18} /> Makanan
              </Link>
              <Link to="/laundry" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-500 transition-colors">
                <Shirt className="inline mr-1" size={18} /> Laundry
              </Link>
              <Link to="/transport" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-500 transition-colors">
                <Car className="inline mr-1" size={18} /> Transportasi
              </Link>
              <Link to="/community" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-500 transition-colors">
                <Users className="inline mr-1" size={18} /> Komunitas
              </Link>
              <Link to="/jobs" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-500 transition-colors">
                <Briefcase className="inline mr-1" size={18} /> Lowongan
              </Link>
            </div>
          </div>
          <div className="hidden md:flex items-center ml-4">
            {isLoggedIn ? (
              <Link to="/profile" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-500 transition-colors">
                <UserCircle className="inline mr-1" size={20} /> Profil
              </Link>
            ) : (
              <Link to="/login" className="px-3 py-2 rounded-md text-sm font-medium hover:bg-cyan-500 transition-colors">
                <LogIn className="inline mr-1" size={20} /> Masuk
              </Link>
            )}
          </div>
          <div className="-mr-2 flex md:hidden">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-white hover:bg-cyan-500 focus:outline-none"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link to="/" className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-500 transition-colors">
              <House className="inline mr-2" size={18} /> Beranda
            </Link>
            <Link to="/rooms" className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-500 transition-colors">
              <House className="inline mr-2" size={18} /> Kamar
            </Link>
            <Link to="/market" className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-500 transition-colors">
              <ShoppingBag className="inline mr-2" size={18} /> Mini Market
            </Link>
            <Link to="/food" className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-500 transition-colors">
              <Coffee className="inline mr-2" size={18} /> Makanan
            </Link>
            <Link to="/laundry" className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-500 transition-colors">
              <Shirt className="inline mr-2" size={18} /> Laundry
            </Link>
            <Link to="/transport" className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-500 transition-colors">
              <Car className="inline mr-2" size={18} /> Transportasi
            </Link>
            <Link to="/community" className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-500 transition-colors">
              <Users className="inline mr-2" size={18} /> Komunitas
            </Link>
            <Link to="/jobs" className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-500 transition-colors">
              <Briefcase className="inline mr-2" size={18} /> Lowongan
            </Link>
            {isLoggedIn ? (
              <Link to="/profile" className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-500 transition-colors">
                <UserCircle className="inline mr-2" size={18} /> Profil
              </Link>
            ) : (
              <Link to="/login" className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-500 transition-colors">
                <LogIn className="inline mr-2" size={18} /> Masuk
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};
