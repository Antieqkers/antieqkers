import React from 'react';
import { Link } from 'react-router-dom';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  link: string;
  bgColor: string;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, icon, link, bgColor }) => {
  return (
    <Link to={link} className="block">
      <div className={`rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 ${bgColor}`}>
        <div className="p-6">
          <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 rounded-full bg-white/20 backdrop-blur-sm">
            {icon}
          </div>
          <h3 className="text-xl font-bold text-center text-white mb-2">{title}</h3>
          <p className="text-white/80 text-center">{description}</p>
        </div>
      </div>
    </Link>
  );
};
