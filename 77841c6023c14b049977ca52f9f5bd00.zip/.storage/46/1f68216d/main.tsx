import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { HomePage } from './pages/HomePage'
import { RoomsPage } from './pages/RoomsPage'
import { MarketPage } from './pages/MarketPage'
import { FoodPage } from './pages/FoodPage'
import { LaundryPage } from './pages/LaundryPage'
import { TransportPage } from './pages/TransportPage'
import { CommunityPage } from './pages/CommunityPage'
import { JobsPage } from './pages/JobsPage'
import { LoginPage } from './pages/LoginPage'
import { RegisterPage } from './pages/RegisterPage'
import { ProfilePage } from './pages/ProfilePage'
import { Navbar } from './components/Navbar'
import { AuthProvider } from './contexts/AuthContext'
import './index.css'

// Create an AppLayout component that includes the Navbar
const AppLayout = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen flex flex-col">
    <Navbar />
    <main className="flex-grow">
      {children}
    </main>
  </div>
);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider>
      <Router>
        <AppLayout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/rooms" element={<RoomsPage />} />
            <Route path="/market" element={<MarketPage />} />
            <Route path="/food" element={<FoodPage />} />
            <Route path="/laundry" element={<LaundryPage />} />
            <Route path="/transport" element={<TransportPage />} />
            <Route path="/community" element={<CommunityPage />} />
            <Route path="/jobs" element={<JobsPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/profile" element={<ProfilePage />} />
          </Routes>
        </AppLayout>
      </Router>
    </AuthProvider>
  </StrictMode>,
)