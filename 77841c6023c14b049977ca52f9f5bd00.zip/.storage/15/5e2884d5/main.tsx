import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { HomePage } from './pages/HomePage'
import { RoomsPage } from './pages/RoomsPage'
import { MarketPage } from './pages/MarketPage'
import { FoodPage } from './pages/FoodPage'
import { LaundryPage } from './pages/LaundryPage'
import { TransportPage } from './pages/TransportPage'
import { CommunityPage } from './pages/CommunityPage'
import { Navbar } from './components/Navbar'
import './index.css'

// Create a JobsPage component since it's linked in the Navbar
const JobsPage = () => (
  <div className="min-h-screen bg-gray-50 pt-16 pb-12">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Lowongan Kerja</h1>
      <p className="text-gray-600 mb-8">Temukan peluang kerja dan magang di sekitar lokasi kos.</p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Placeholder for job listings */}
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-indigo-500">
          <h2 className="font-bold text-xl mb-2">Customer Service</h2>
          <p className="text-gray-700 mb-3">PT. Maju Bersama</p>
          <div className="mb-3">
            <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mr-2">Full Time</span>
            <span className="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded">2km dari kos</span>
          </div>
          <p className="text-gray-600 mb-4">Dibutuhkan customer service dengan kemampuan komunikasi yang baik dan dapat bekerja dengan tim.</p>
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded transition-colors">
            Lamar Sekarang
          </button>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
          <h2 className="font-bold text-xl mb-2">Magang Marketing</h2>
          <p className="text-gray-700 mb-3">CV. Digital Kreasi</p>
          <div className="mb-3">
            <span className="inline-block bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded mr-2">Magang</span>
            <span className="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded">1.5km dari kos</span>
          </div>
          <p className="text-gray-600 mb-4">Kesempatan magang untuk mahasiswa jurusan marketing atau komunikasi. Remote friendly.</p>
          <button className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded transition-colors">
            Lamar Sekarang
          </button>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-yellow-500">
          <h2 className="font-bold text-xl mb-2">Barista</h2>
          <p className="text-gray-700 mb-3">Kopi Santai</p>
          <div className="mb-3">
            <span className="inline-block bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded mr-2">Part Time</span>
            <span className="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded">0.8km dari kos</span>
          </div>
          <p className="text-gray-600 mb-4">Dicari barista untuk shift sore-malam. Pengalaman tidak diutamakan, akan ada training.</p>
          <button className="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded transition-colors">
            Lamar Sekarang
          </button>
        </div>
      </div>
    </div>
  </div>
);

// Create an AppLayout component that includes the Navbar
const AppLayout = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen flex flex-col">
    <Navbar />
    <main className="flex-grow">
      {children}
    </main>
  </div>
);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Router>
      <AppLayout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/rooms" element={<RoomsPage />} />
          <Route path="/market" element={<MarketPage />} />
          <Route path="/food" element={<FoodPage />} />
          <Route path="/laundry" element={<LaundryPage />} />
          <Route path="/transport" element={<TransportPage />} />
          <Route path="/community" element={<CommunityPage />} />
          <Route path="/jobs" element={<JobsPage />} />
        </Routes>
      </AppLayout>
    </Router>
  </StrictMode>,
)