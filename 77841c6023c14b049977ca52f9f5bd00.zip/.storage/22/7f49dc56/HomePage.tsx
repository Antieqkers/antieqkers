import React from 'react';
import { ServiceCard } from '../components/ServiceCard';
import { Briefcase, Car, Coffee, House, Shirt, ShoppingBag, Users } from 'lucide-react';

export const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-purple-700 to-indigo-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
              Selamat Datang di ANTIEQkers
            </h1>
            <p className="text-lg md:text-xl max-w-3xl mx-auto mb-8">
              Solusi lengkap untuk kebutuhan hidup di kos-kosan Anda. Dari booking kamar hingga layanan sehari-hari.
            </p>
            <button className="bg-white text-indigo-700 hover:bg-gray-100 px-6 py-3 rounded-lg font-medium shadow-md transition-colors">
              Mulai Sekarang
            </button>
          </div>
        </div>
      </div>

      {/* Services Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Layanan Kami</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <ServiceCard
            title="Booking Kamar"
            description="Temukan dan pesan kamar kos yang sesuai dengan kebutuhan Anda"
            icon={<House size={24} className="text-white" />}
            link="/rooms"
            bgColor="bg-gradient-to-br from-blue-500 to-blue-700"
          />
          <ServiceCard
            title="Mini Market"
            description="Belanja kebutuhan sehari-hari tanpa perlu keluar kos"
            icon={<ShoppingBag size={24} className="text-white" />}
            link="/market"
            bgColor="bg-gradient-to-br from-green-500 to-green-700"
          />
          <ServiceCard
            title="Pesan Makanan"
            description="Pesan makanan dari restoran favorit di sekitar Anda"
            icon={<Coffee size={24} className="text-white" />}
            link="/food"
            bgColor="bg-gradient-to-br from-red-500 to-red-700"
          />
          <ServiceCard
            title="Laundry"
            description="Layanan laundry dengan antar-jemput ke kamar Anda"
            icon={<Shirt size={24} className="text-white" />}
            link="/laundry"
            bgColor="bg-gradient-to-br from-yellow-500 to-yellow-700"
          />
          <ServiceCard
            title="Transportasi"
            description="Layanan antar-jemput untuk kebutuhan perjalanan Anda"
            icon={<Car size={24} className="text-white" />}
            link="/transport"
            bgColor="bg-gradient-to-br from-purple-500 to-purple-700"
          />
          <ServiceCard
            title="Komunitas"
            description="Bergabung dengan komunitas penghuni kos dan ikuti kegiatan bersama"
            icon={<Users size={24} className="text-white" />}
            link="/community"
            bgColor="bg-gradient-to-br from-pink-500 to-pink-700"
          />
          <ServiceCard
            title="Lowongan Kerja"
            description="Temukan peluang kerja dan magang di sekitar lokasi kos"
            icon={<Briefcase size={24} className="text-white" />}
            link="/jobs"
            bgColor="bg-gradient-to-br from-indigo-500 to-indigo-700"
          />
          <div className="rounded-xl overflow-hidden shadow-lg bg-gradient-to-br from-gray-700 to-gray-900 p-6 flex flex-col items-center justify-center">
            <h3 className="text-xl font-bold text-white mb-2">Lainnya</h3>
            <p className="text-white/80 text-center">Fitur lainnya akan segera hadir</p>
            <span className="mt-4 px-4 py-2 bg-white/20 rounded-full text-white text-sm">Segera Hadir</span>
          </div>
        </div>
      </div>

      {/* Testimonials */}
      <div className="bg-gray-100 py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Apa Kata Pengguna</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-indigo-600 font-bold">AA</span>
                </div>
                <div>
                  <h4 className="font-semibold">Anisa Aulia</h4>
                  <p className="text-gray-600 text-sm">Mahasiswa</p>
                </div>
              </div>
              <p className="text-gray-700">"Aplikasi ini sangat membantu saya yang sibuk kuliah. Saya bisa pesan makanan dan laundry tanpa harus keluar kamar."</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-green-600 font-bold">BP</span>
                </div>
                <div>
                  <h4 className="font-semibold">Budi Pratama</h4>
                  <p className="text-gray-600 text-sm">Karyawan</p>
                </div>
              </div>
              <p className="text-gray-700">"Fitur lowongan kerja sangat membantu saya menemukan pekerjaan yang dekat dengan kos. Transportasi antar-jemput juga sangat nyaman."</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-purple-600 font-bold">DW</span>
                </div>
                <div>
                  <h4 className="font-semibold">Dina Widya</h4>
                  <p className="text-gray-600 text-sm">Freelancer</p>
                </div>
              </div>
              <p className="text-gray-700">"Mini market online sangat membantu saat saya butuh kebutuhan mendadak. Komunitas di aplikasi juga membantu saya bertemu teman baru."</p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="bg-indigo-700 rounded-2xl shadow-xl overflow-hidden">
          <div className="px-6 py-12 md:p-12 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">Siap Untuk Memulai?</h2>
            <p className="text-indigo-100 mb-8 max-w-2xl mx-auto">
              Nikmati kemudahan hidup di kos dengan ANTIEQkers. Daftar sekarang dan dapatkan diskon 20% untuk pemesanan pertama!
            </p>
            <button className="bg-white text-indigo-700 hover:bg-gray-100 px-6 py-3 rounded-lg font-medium shadow-md transition-colors">
              Daftar Sekarang
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
